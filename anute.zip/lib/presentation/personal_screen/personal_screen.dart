import 'package:gokul_s_application3/widgets/custom_drop_down.dart';
import 'package:gokul_s_application3/widgets/custom_text_form_field.dart';
import 'package:gokul_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:gokul_s_application3/core/app_export.dart';

// ignore_for_file: must_be_immutable
class PersonalScreen extends StatelessWidget {
  PersonalScreen({Key? key}) : super(key: key);

  List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

  TextEditingController inputFieldController = TextEditingController();

  TextEditingController inputFieldController1 = TextEditingController();

  TextEditingController inputFieldController2 = TextEditingController();

  TextEditingController inputFieldController3 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.all(23.h),
                child: Column(children: [
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Text("Auto Nute",
                          style: theme.textTheme.displaySmall)),
                  SizedBox(height: 50.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text("Select the corp",
                              style: theme.textTheme.headlineSmall))),
                  SizedBox(height: 31.v),
                  Padding(
                      padding: EdgeInsets.only(left: 16.h, right: 15.h),
                      child: CustomDropDown(
                          icon: Container(
                              margin:
                                  EdgeInsets.fromLTRB(30.h, 24.v, 16.h, 18.v),
                              child: CustomImageView(
                                  imagePath: ImageConstant.imgDownArrow1,
                                  height: 13.v,
                                  width: 16.h)),
                          hintText: "Choose",
                          items: dropdownItemList,
                          onChanged: (value) {})),
                  SizedBox(height: 37.v),
                  Text("Or",
                      style: CustomTextStyles.titleMediumPrimaryContainer),
                  SizedBox(height: 36.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text("Enter Nutrient Level",
                              style: theme.textTheme.headlineSmall))),
                  SizedBox(height: 33.v),
                  _buildInputField(context),
                  SizedBox(height: 33.v),
                  _buildInputField1(context),
                  SizedBox(height: 33.v),
                  _buildInputField2(context),
                  SizedBox(height: 33.v),
                  _buildInputField3(context),
                  SizedBox(height: 33.v),
                  _buildSubmit(context),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  Widget _buildInputField(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 16.h, right: 15.h),
        child: CustomTextFormField(
            controller: inputFieldController, hintText: "Nitrogen"));
  }

  /// Section Widget
  Widget _buildInputField1(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 16.h, right: 15.h),
        child: CustomTextFormField(
            controller: inputFieldController1, hintText: "potassium"));
  }

  /// Section Widget
  Widget _buildInputField2(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 16.h, right: 15.h),
        child: CustomTextFormField(
            controller: inputFieldController2, hintText: "phosphorus"));
  }

  /// Section Widget
  Widget _buildInputField3(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 16.h, right: 15.h),
        child: CustomTextFormField(
            controller: inputFieldController3,
            hintText: "Water level",
            textInputAction: TextInputAction.done));
  }

  /// Section Widget
  Widget _buildSubmit(BuildContext context) {
    return CustomElevatedButton(
        text: "Submit",
        margin: EdgeInsets.only(left: 16.h, right: 15.h),
        onPressed: () {
          personal_two(context);
        });
  }

  /// Navigates to the personalTwoScreen when the action is triggered.
  personal_two(BuildContext context) {
    Navigator.popAndPushNamed(context, AppRoutes.personalTwoScreen);
  }
}
