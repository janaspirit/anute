import 'package:gokul_s_application3/widgets/custom_text_form_field.dart';
import 'package:gokul_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:gokul_s_application3/core/app_export.dart';

// ignore_for_file: must_be_immutable
class PersonalOneScreen extends StatelessWidget {
  PersonalOneScreen({Key? key}) : super(key: key);

  TextEditingController inputFieldController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 38.h, vertical: 163.v),
                            child: Column(children: [
                              Text("Log IN",
                                  style: theme.textTheme.headlineLarge),
                              Spacer(flex: 45),
                              CustomTextFormField(
                                  controller: inputFieldController,
                                  hintText: "User Id"),
                              SizedBox(height: 24.v),
                              CustomTextFormField(
                                  controller: passwordController,
                                  hintText: "Password",
                                  textInputAction: TextInputAction.done,
                                  textInputType: TextInputType.visiblePassword,
                                  suffix: Container(
                                      margin: EdgeInsets.fromLTRB(
                                          30.h, 18.v, 16.h, 18.v),
                                      child: CustomImageView(
                                          imagePath: ImageConstant.imgIcon,
                                          height: 20.adaptSize,
                                          width: 20.adaptSize)),
                                  suffixConstraints:
                                      BoxConstraints(maxHeight: 56.v),
                                  obscureText: true,
                                  contentPadding: EdgeInsets.only(
                                      left: 16.h, top: 18.v, bottom: 18.v)),
                              SizedBox(height: 20.v),
                              CustomElevatedButton(
                                  text: "LogIn",
                                  onPressed: () {
                                    personalone(context);
                                  }),
                              Spacer(flex: 54)
                            ])))))));
  }

  /// Navigates to the personalScreen when the action is triggered.
  personalone(BuildContext context) {
    Navigator.popAndPushNamed(context, AppRoutes.personalScreen);
  }
}
