import '../personal_two_screen/widgets/framefiftyone_item_widget.dart';
import 'package:gokul_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:gokul_s_application3/core/app_export.dart';

class PersonalTwoScreen extends StatelessWidget {
  const PersonalTwoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 33.h, vertical: 31.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Loaded", style: CustomTextStyles.headlineLargeBold),
                      SizedBox(height: 44.v),
                      Text("Current Values",
                          style: theme.textTheme.headlineSmall),
                      SizedBox(height: 45.v),
                      Padding(
                          padding: EdgeInsets.only(right: 1.h),
                          child: _buildTwentyOne(context,
                              pottassium: "Water :", phosphorus: "Nitrogen :")),
                      SizedBox(height: 28.v),
                      Padding(
                          padding: EdgeInsets.only(right: 1.h),
                          child: _buildTwentyOne(context,
                              pottassium: "Pottassium :",
                              phosphorus: "phosphorus :")),
                      SizedBox(height: 47.v),
                      Text("ON / OFF", style: theme.textTheme.headlineSmall),
                      SizedBox(height: 44.v),
                      _buildFrameFiftyOne(context),
                      SizedBox(height: 48.v),
                      Text("To change the crop",
                          style: theme.textTheme.headlineSmall),
                      SizedBox(height: 42.v),
                      CustomElevatedButton(
                          text: "Back",
                          margin: EdgeInsets.only(right: 11.h),
                          onPressed: () {
                            personal(context);
                          }),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Section Widget
  Widget _buildFrameFiftyOne(BuildContext context) {
    return Wrap(
        runSpacing: 40.v,
        spacing: 40.h,
        children:
            List<Widget>.generate(4, (index) => FramefiftyoneItemWidget()));
  }

  /// Common widget
  Widget _buildTwentyOne(
    BuildContext context, {
    required String pottassium,
    required String phosphorus,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Container(
          width: 165.h,
          padding: EdgeInsets.fromLTRB(16.h, 18.v, 63.h, 18.v),
          decoration: AppDecoration.outlinePrimary
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
          child: Text(pottassium,
              style: theme.textTheme.bodyLarge!
                  .copyWith(color: theme.colorScheme.secondaryContainer))),
      Container(
          width: 165.h,
          padding: EdgeInsets.fromLTRB(16.h, 19.v, 60.h, 17.v),
          decoration: AppDecoration.outlinePrimary
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder10),
          child: Text(phosphorus,
              style: theme.textTheme.bodyLarge!
                  .copyWith(color: theme.colorScheme.secondaryContainer)))
    ]);
  }

  /// Navigates to the personalScreen when the action is triggered.
  personal(BuildContext context) {
    Navigator.popAndPushNamed(context, AppRoutes.personalScreen);
  }
}
