class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Personal One images
  static String imgIcon = '$imagePath/img_icon.svg';

  // Personal images
  static String imgDownArrow1 = '$imagePath/img_down_arrow_1.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
